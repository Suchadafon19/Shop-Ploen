<template>
<div class="basket">
<div class="container">
  	<h2>ตะกร้าสินค้า</h2> 
		<div v-if="$store.state.cart.length > 0">          
  				
				<table class="table table-striped">

    			<thead>
      				<tr>
      					<th></th>
        				<th>สินค้า</th>
        				<th>ราคา</th>
        				<th>จำนวนสินค้าที่เลือก</th>
        				<th>ราคารวม</th>
      				</tr>
    			</thead>
    		
  			</table>
				<div v-for="item in $store.state.cart"
                :key="item.productNo">
				<table class="table table-striped">
						<tbody>
					
      				<tr>
      					<td class="column-1">
							<div class="how-itemcart1">
								<img src="" alt="">
							</div>
						</td>
        				<td>{{item.productName}}</td>
        				<td>{{item.price}} บาท</td>
        				<td>{{item.quantity}}</td>
        				<td>{{item.totalPrice}}บาท</td>
      				</tr>
						
      				
    			</tbody>
				</table>
				</div>
				</div>
		
</div>

<div class="container">
	<h3>ราคารวมทั้งหมด : บาท</h3>  
</div>

<br>
<div class="container">
  <center>
  	<router-link to="/">
  		<button type="button" class="btn btn-primary btn-block" id="basket1" >เพิ่มสินค้า</button>
  	</router-link>
  	<router-link to="/addressField">
  		<button type="button" class="btn btn-default btn-block" id="basket2">ยืนยันการสั่งซื้อ</button>
  	</router-link>
  </center>
</div>

<br><br><br>
</div>
</template>

  <style type="text/css">
#foot{
  background-color: #212121;
}
h4,h5{
  color: white;
}
#basket1,#basket2{
  padding: 10px;
  width: 500px;
  margin: 5px;
}
  </style>



