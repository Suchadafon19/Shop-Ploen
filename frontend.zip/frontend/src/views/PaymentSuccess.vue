<template>
    <div class="paymentSuccess">
        <section>
		<br>
 		<h2 align="center">ชำระเงินสำเร็จ</h2>
  		<br><br><br>
  		<h3 align="center">ขอบคุณที่ใช้บริการ Shoppearn</h3>

	</section><br><br><br>
    </div>
</template>

<style>
 #foot{
  background-color: #212121;
 }

body{
  color: #000000;
  background-color: #e9f1f0;
  margin: 0px;
}

section{
  width: 850px;
  min-height: 300px;
  overflow: auto;
  background-color: #FFFFFF;
  margin: 0 auto;
  border-radius: 10px;
  border: 1px solid #CCCCCC;
  box-shadow: 4px 4px 4px 4px #BBBBBB;
  margin-top: 20px;
  margin-bottom: 20px;
}

.payment_detail {
  margin: 10px;
  padding: 10px;
  margin-left: 180px;
}
h2{
   color: green;
}
h4,h5{
  color: white;
}

#pay_num {
	width: 400px;
	height: 30px;
	margin: 1px;
	background: #EAEFF9;
	top:50%;
	left:50%;
	margin-left:74px;
	margin-top:0px;
}
#pay_name {
	width: 400px;
	height: 30px;
	margin: 1px;
	background: #EAEFF9;
	top:50%;
	left:50%;
	margin-left:73px;
	margin-top:-30px;
}
#pay_date {
	width: 400px;
	height: 30px;
	margin: 1px;
	background: #EAEFF9;
	margin-left:68px;
	margin-top:-60px;
}
#pay_ccv {
	width: 400px;
	height: 30px;
	margin: 1px;
	background: #EAEFF9;
	margin-left:110px;
	margin-top:-140px;
}

#pay1{
	width: 100px;
	height: 30px;
	margin: 1px;
	background: #FFFFFF;
	margin-left:100px;
	margin-top:-140px;
	text-align: right;
}
#pay2{
	width: 100px;
	height: 30px;
	margin: 1px;
	background: #FFFFFF;
	margin-left:115px;
	margin-top:-140px;
	text-align: right;
}

#pay3{
	width: 100px;
	height: 30px;
	margin: 1px;
	background: #FFFFFF;
	margin-left:142px;
	margin-top:-140px;
	text-align: right;
	font-weight: bold;
}

.button1 {
  display: inline-block;
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 15px;
  padding: 10px;
  width: 150px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}
.button2 {
  display: inline-block;
  border-radius: 4px;
  background-color: #4CAF50;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 15px;
  padding: 10px;
  width: 150px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}
</style>
