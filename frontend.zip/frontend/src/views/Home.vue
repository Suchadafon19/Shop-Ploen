<template>
  <div class="home">
    <!-- <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/> -->
    <div class='container' style="background-color: black; width:100%">
      <div class='product' style="height: 330px" v-for="item in product" :key="item.productNo">
        <router-link to="/productDetail"><img src="" style="width: 118%; height: 63%" @click="viewProductDetail(item.productNo)"/></router-link>
        <h2 class='header'>{{ item.productName }}</h2>
        <p class='price'>{{item.price}} ฿</p>
        <div class='btn'><p @click="addToCart(item)">add to cart</p></div>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import axios from 'axios'
export default {
  name: 'home',
  components: {
    HelloWorld
  },
  data () {
    return {
      product: ''
    }
  },
  methods: {
    getProduct: async function () {
      let product = await axios.get('http://localhost:8081/getAllProduct')
      this.product = product.data
      console.log(this.product)
    },
    viewProductDetail(productNo) {
      this.$store.commit('viewProductDetail', productNo);
    },
    addToCart(item) {
        this.$store.commit('addToCart', item);
    }
  },
  mounted () {
    this.getProduct()
  }
}
</script>
<style>

  body {
    background-color: #0b0b0b;
    font-family: 'Nunito', sans-serif;
  }
  nav {
    position: fixed;
    z-index: 999;
    width: 100%;
    height: 70px;
    background-color: #ffffff;
    line-height: 70px;
  }
  nav .mini {
    position: fixed;
    top: 80px;
    right: 10px;
    background: #FFF;
    padding: 40px;
    opacity: 0;
    visibility: hidden;
    transition: opacity .2s ease .2s;
  }

  nav .cart {
    position: relative;
    float: right;
    margin-right: 50px;
    height: 20px;
    line-height: 70px;
    font-size: 28px;
    height: 100%;
    cursor: pointer;
  }
  nav .cart span {
    height: 100%;
    float: left;
    margin-right: 20px;
    opacity: 1;
    color: #fff;
    font-size: 18px;
    font-family: 'Nunito', sans-serif;
  }
  nav .cart span.updateQuantity:before, nav .cart span.updateQuantity:after {
    top: 0;
    bottom: 0;
    opacity: 1;
    width: 30px;
    transition: all .2s ease, top .3s ease .4s, bottom .3s ease .4s;
  }
  nav .cart span.update {
    transition: color .2s ease .6s;
    color: #000;
  }
  nav .cart span.update:before {
    top: -30px;
    width: 30px;
    opacity: 1;
    transition: all .2s ease, top .3s ease .4s, bottom .3s ease .4s;
  }
  nav .cart span.update:after {
    top: 30px;
    width: 30px;
    opacity: 1;
    transition: all .2s ease, top .3s ease .4s, bottom .3s ease .4s;
  }
  nav .cart span:before, nav .cart span:after {
    content: "";
    position: absolute;
    width: 0px;
    height: 2px;
    background-color: #0b0b0b;
    left: -10px;
    right: 40px;
    top: 2px;
    bottom: 0;
    margin: auto;
  }
  nav ul {
    float: left;
  }
  nav ul li {
    font-weight: bold;
    display: inline-block;
    margin-left: 50px;
    color: #0b0b0b;
    font-size: 12px;
  }

  .container {
    padding: 20px;
    padding-top: 100px;
    text-align: left;
  }
  .container .product {
    position: relative;
    overflow: hidden;
    width: 200px;
    height: 240px;
    display: inline-block;
    border-radius: 4px;
    background-color: rgba(255, 255, 255, 0.45);
    margin: 20px;
    padding: 15px;
  }
  .container .product img {
    position: relative;
    top: -15px;
    left: -15px;
    transition: all .2s ease;
    -webkit-clip-path: polygon(0 100%, 0 0, 100% 0, 100% 70%);
            clip-path: polygon(0 100%, 0 0, 100% 0, 100% 70%);
    border-top-right-radius: 4px;
    border-top-left-radius: 4px;
  }
  .container .product img:hover {
    -webkit-clip-path: polygon(0 100%, 0 0, 100% 0, 100% 100%);
            clip-path: polygon(0 100%, 0 0, 100% 0, 100% 100%);
    -webkit-transform: scale(1.1);
            transform: scale(1.1);
  }
  .container .product h2 {
    text-align: left;
    color: #fff;
    font-size: 14px;
    font-weight: bold;
    margin-bottom: 4px;
  }
  .container .product .description {
    text-align: left;
    font-size: 11px;
    color: #fff;
    max-height: 23px;
    overflow: hidden;
  }
  .container .product .price {
    text-align: right;
    font-size: 18px;
    color: #fff;
    margin-top: 6px;
  }
  .container .product .btn {
    position: absolute;
    font-size: 11px;
    font-weight: bold;
    float: right;
    padding: 10px;
    border: 2px solid #00fefe;
    border-radius: 20px;
    bottom: 10px;
    right: 10px;
    color: #00fefe;
    cursor: pointer;
    overflow: hidden;
    transition: all .2s ease;
  }
  .container .product .btn.ok {
    background-color: rgba(0, 254, 254, 0.4);
    color: #fff;
  }
  .container .product .btn.ok:after {
    content: "\e080";
    color: #fff;
  }
  .container .product .btn:hover {
    padding-right: 25px;
  }
  .container .product .btn:hover:after {
    margin-left: 5px;
  }
  .container .product .btn:after {
    font-family: 'simple-line-icons';
    content: "\e095";
    transition: all .2s ease;
    position: absolute;
    color: #00fefe;
    margin-left: 30px;
    transition: all .2s ease;
  }
</style>
